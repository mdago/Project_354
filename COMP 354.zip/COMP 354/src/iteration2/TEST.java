package iteration2;

import java.io.IOException;
import java.util.Calendar;

import yahoofinance.Stock;
import yahoofinance.YahooFinance;
import yahoofinance.histquotes.Interval;

public class TEST {

	public static void main(String[] args) throws IOException {
		Calendar start = Calendar.getInstance();
		Calendar end = Calendar.getInstance();
		
		start.add(Calendar.YEAR, -100);
 	   
		   Stock stock = YahooFinance.get("CSCO", start, end, Interval.MONTHLY);
		   
		   System.out.println(stock.getHistory().size());
		   
		   double[] closings = new double[stock.getHistory().size()];
		   
		   //	add data to array 
	        for (int i = 0; i < stock.getHistory().size(); ++i) {
	        	closings[i] = stock.getHistory().get(stock.getHistory().size() - i - 1).getClose().doubleValue();
	        }
	        
	        for (int i = 0; i < closings.length; ++i) {
	        	if (i % 15 == 0)
	        		System.out.println();
	        	System.out.print(closings[i] + " ");
	        }
	        System.out.println();

	}

}

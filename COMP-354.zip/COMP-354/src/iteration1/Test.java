package iteration1;

public class Test {

	public static void main(String[] args) {
		Calculator c = new Calculator();

		double[] a = {13,1,351,351,351,31,231,5,1,13,51351,31,351,31,531,31,531,31,51,351,531,351,531};
		double[] res = c.calculateMovingAverage(a, 5);
		
		for (int i = 0; i < res.length; ++i)
			System.out.print(res[i] + " ");
	}

}
